import { MenuItem } from './types';

export const MENU_ITEMS: MenuItem[] = [
  {
    id: '1',
    name: 'Fresh Orange Juice',
    description: 'Freshly squeezed with no added sugar',
    price: 150,
    category: 'Beverages',
    imageUrl: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?auto=format&fit=crop&q=80&w=400',
    customizations: {
      type: 'multiple',
      options: [
        { name: 'Add Ice', price: 0 },
        { name: 'Extra Mint', price: 20 }
      ]
    }
  },
  {
    id: '2',
    name: 'Mango Lassi',
    description: 'Creamy blended yoghurt drink with sweet mangoes',
    price: 160,
    category: 'Beverages',
    imageUrl: 'https://images.unsplash.com/photo-1570696516188-ade861b84a49?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '3',
    name: 'Cold Brew',
    description: '12-hour cold steeped coffee — smooth, bold, and refreshing',
    price: 220,
    category: 'Coffee',
    imageUrl: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '4',
    name: 'Espresso',
    description: 'Bold double-shot espresso',
    price: 140,
    category: 'Coffee',
    imageUrl: 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '5',
    name: 'Cappuccino',
    description: 'Rich espresso topped with velvety steamed milk foam',
    price: 180,
    category: 'Coffee',
    imageUrl: 'https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '6',
    name: 'Masala Chai',
    description: 'Spiced Indian tea brewed with ginger and cardamom',
    price: 120,
    category: 'Tea',
    imageUrl: 'https://images.unsplash.com/photo-1561336313-0bd5e0b27ec8?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '7',
    name: 'Veg Club Sandwich',
    description: 'Triple-layered with fresh veggies and mint chutney',
    price: 220,
    category: 'Snacks',
    imageUrl: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '8',
    name: 'Paneer Tikka Sandwich',
    description: 'Grilled paneer tikka stuffed in toasted bread',
    price: 280,
    category: 'Snacks',
    imageUrl: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '9',
    name: 'Avocado Toast',
    description: 'Smashed avocado on sourdough with cherry tomatoes',
    price: 320,
    category: 'Snacks',
    imageUrl: 'https://images.unsplash.com/photo-1541519227354-08fa5d50c44d?auto=format&fit=crop&q=80&w=400',
    customizations: {
      type: 'multiple',
      options: [
        { name: 'Add Egg', price: 60 },
        { name: 'Extra Avocado', price: 40 }
      ]
    }
  },
  {
    id: '10',
    name: 'Pasta Alfredo',
    description: 'Creamy white sauce pasta with herbs',
    price: 280,
    category: 'Meals',
    imageUrl: 'https://images.unsplash.com/photo-1645112411341-6c4fd023714a?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '11',
    name: 'Chocolate Lava Brownie',
    description: 'Warm molten chocolate brownie served fresh',
    price: 240,
    category: 'Desserts',
    imageUrl: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: '12',
    name: 'Chocolate Brownie',
    description: 'Warm fudgy brownie with dark chocolate',
    price: 160,
    category: 'Desserts',
    imageUrl: 'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&q=80&w=400',
  }
];

export const CATEGORIES = ['All', 'Coffee', 'Tea', 'Beverages', 'Snacks', 'Desserts', 'Meals'];
