export interface CustomizationOption {
  name: string;
  price: number;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  imageUrl: string;
  customizations?: {
    type: 'single' | 'multiple';
    options: CustomizationOption[];
  };
}

export interface CartItem {
  id: string; // unique id for cart entry
  menuItem: MenuItem;
  quantity: number;
  selectedCustomizations: CustomizationOption[];
  specialRequest?: string;
}

export type UserRole = 'admin' | 'customer';

export interface User {
  uid: string;
  email: string;
  role: UserRole;
}

export interface Order {
  id: string;
  tableNumber: string;
  items: CartItem[];
  total: number;
  status: 'Pending' | 'Preparing' | 'Ready' | 'Served' | 'Cancelled';
  createdAt: number;
  customerUid: string;
  note?: string;
  paymentMethod?: string;
  rejectionReason?: string;
}
