import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Plus, Minus, X, Coffee, LogOut, CheckCircle2, Menu, HelpCircle, History, Clock, ArrowLeft, Smartphone, Landmark, HandCoins } from 'lucide-react';
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, orderBy } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { MENU_ITEMS, CATEGORIES } from '../data';
import { MenuItem, CartItem, CustomizationOption, Order } from '../types';
import { cn } from '../lib/utils';

interface CustomerMenuProps {
  tableNumber: string;
  onLogout: () => void;
}

export function CustomerMenu({ tableNumber, onLogout }: CustomerMenuProps) {
  const [activeCategory, setActiveCategory] = useState('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [isOrdersModalOpen, setIsOrdersModalOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [isOrderPlacedOpen, setIsOrderPlacedOpen] = useState(false);
  const [orderNote, setOrderNote] = useState('');
  const [pastOrders, setPastOrders] = useState<Order[]>([]);
  const [rejectedOrderAlert, setRejectedOrderAlert] = useState<Order | null>(null);

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'orders'),
      where('customerUid', '==', auth.currentUser.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ordersData: Order[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        ordersData.push({
          ...data,
          id: doc.id,
          createdAt: data.createdAt?.toMillis() || Date.now(),
        } as Order);
      });
      
      // Check for newly rejected orders
      const previousOrders = pastOrders;
      ordersData.forEach(order => {
        if (order.status === 'Cancelled') { // In types it's 'Cancelled', in rules I used 'Cancelled'
          const prevOrder = previousOrders.find(o => o.id === order.id);
          if (!prevOrder || prevOrder.status !== 'Cancelled') {
            setRejectedOrderAlert(order);
          }
        }
      });

      setPastOrders(ordersData);
    });

    return () => unsubscribe();
  }, [tableNumber]);

  // Modal State
  const [quantity, setQuantity] = useState(1);
  const [selectedCustomizations, setSelectedCustomizations] = useState<CustomizationOption[]>([]);
  const [specialRequest, setSpecialRequest] = useState('');

  const filteredItems = activeCategory === 'All' 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === activeCategory);

  const cartTotal = cart.reduce((sum, item) => {
    const itemTotal = item.menuItem.price + item.selectedCustomizations.reduce((cSum, c) => cSum + c.price, 0);
    return sum + (itemTotal * item.quantity);
  }, 0);

  const handleAddToCart = () => {
    if (!selectedItem) return;

    const newItem: CartItem = {
      id: Math.random().toString(36).substring(7),
      menuItem: selectedItem,
      quantity,
      selectedCustomizations,
      specialRequest
    };

    setCart([...cart, newItem]);
    closeModal();
  };

  const closeModal = () => {
    setSelectedItem(null);
    setQuantity(1);
    setSelectedCustomizations([]);
    setSpecialRequest('');
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setIsCartOpen(false);
    setIsPaymentOpen(true);
  };

  const handlePaymentSelection = (method: string) => {
    if (method === 'UPI' || method === 'Net Banking') {
      setIsProcessingPayment(true);
      setTimeout(() => {
        setIsProcessingPayment(false);
        finalizeOrder(method);
      }, 2000);
    } else {
      finalizeOrder(method);
    }
  };

  const finalizeOrder = async (method: string) => {
    if (!auth.currentUser) return;

    const newOrderData = {
      tableNumber,
      items: cart,
      total: cartTotal,
      status: 'Pending',
      createdAt: serverTimestamp(),
      customerUid: auth.currentUser.uid,
      note: orderNote,
      paymentMethod: method
    };

    try {
      await addDoc(collection(db, 'orders'), newOrderData);
      setCart([]);
      setOrderNote('');
      setIsPaymentOpen(false);
      setIsOrderPlacedOpen(true);
    } catch (error) {
      console.error("Error adding order: ", error);
      alert("Failed to place order. Please try again.");
    }
  };

  const toggleCustomization = (option: CustomizationOption) => {
    if (!selectedItem?.customizations) return;
    
    if (selectedItem.customizations.type === 'single') {
      setSelectedCustomizations([option]);
    } else {
      const exists = selectedCustomizations.find(c => c.name === option.name);
      if (exists) {
        setSelectedCustomizations(selectedCustomizations.filter(c => c.name !== option.name));
      } else {
        setSelectedCustomizations([...selectedCustomizations, option]);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#F5E6D3] pb-24">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#3E2723] shadow-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
              <Coffee className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-[family-name:var(--font-brand)] text-white leading-tight">Demo Cafe</h1>
              <p className="text-white/70 text-xs">Table {tableNumber}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors flex items-center gap-2 px-4"
            >
              <ShoppingCart className="w-5 h-5 text-white" />
              <span className="font-medium text-white">Cart</span>
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-[#3E2723] text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#3E2723]">
                  {cart.length}
                </span>
              )}
            </button>
            <button onClick={() => setIsNavOpen(true)} className="p-2 text-white/70 hover:text-white">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Categories */}
        <div className="flex overflow-x-auto hide-scrollbar px-4 py-3 gap-2">
          {CATEGORIES.map(category => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={cn(
                "whitespace-nowrap px-5 py-2 rounded-full text-sm font-medium transition-colors border",
                activeCategory === category 
                  ? "bg-white text-[#6B4423] border-white" 
                  : "bg-white/10 text-white/80 border-white/20 hover:border-white/40"
              )}
            >
              {category}
            </button>
          ))}
        </div>
      </header>

      {/* Menu Grid */}
      <main className="p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredItems.map((item) => (
          <motion.div 
            key={item.id}
            layoutId={`card-${item.id}`}
            onClick={() => setSelectedItem(item)}
            className="bg-white rounded-2xl overflow-hidden shadow-sm border border-[#3E2723]/10 cursor-pointer flex flex-col"
          >
            <div className="aspect-square relative overflow-hidden bg-stone-100">
              <img src={item.imageUrl} alt={item.name} className="object-cover w-full h-full" />
            </div>
            <div className="p-3 flex flex-col flex-1">
              <h3 className="font-serif font-bold text-[#3E2723] leading-tight mb-1">{item.name}</h3>
              <p className="text-[#6B4423]/70 text-xs line-clamp-2 mb-3 flex-1">{item.description}</p>
              <div className="flex items-center justify-between mt-auto">
                <span className="font-medium text-[#3E2723]">₹{item.price}</span>
                <button className="w-8 h-8 rounded-full bg-[#6B4423] text-white flex items-center justify-center hover:bg-[#3E2723] transition-colors">
                  <Plus className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </main>

      {/* Nav Drawer */}
      <AnimatePresence>
        {isNavOpen && (
          <div className="fixed inset-0 z-50 flex justify-end">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsNavOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-white w-64 h-full relative z-10 flex flex-col shadow-2xl"
            >
              <div className="p-4 border-b border-stone-100 flex justify-end">
                <button onClick={() => setIsNavOpen(false)} className="p-2 text-stone-500 hover:bg-stone-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 py-4 flex flex-col gap-2 px-4">
                <button onClick={() => { setIsOrdersModalOpen(true); setIsNavOpen(false); }} className="flex items-center gap-3 p-3 text-stone-700 hover:bg-stone-100 rounded-xl font-medium transition-colors text-left">
                  <History className="w-5 h-5" /> Your order
                </button>
                <button onClick={() => alert('Help is on the way!')} className="flex items-center gap-3 p-3 text-stone-700 hover:bg-stone-100 rounded-xl font-medium transition-colors text-left">
                  <HelpCircle className="w-5 h-5" /> Help
                </button>
              </div>
              <div className="p-4 border-t border-stone-100">
                <button onClick={onLogout} className="flex items-center gap-3 p-3 text-red-600 hover:bg-red-50 rounded-xl font-medium transition-colors w-full text-left">
                  <LogOut className="w-5 h-5" /> Sign out
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Item Modal */}
      <AnimatePresence>
        {selectedItem && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 sm:p-0">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeModal}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              layoutId={`card-${selectedItem.id}`}
              className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden relative z-10 max-h-[90vh] flex flex-col"
            >
              <button 
                onClick={closeModal}
                className="absolute top-4 right-4 w-8 h-8 bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center text-white z-10 shadow-sm"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="aspect-video relative bg-stone-100 shrink-0">
                <img src={selectedItem.imageUrl} alt={selectedItem.name} className="w-full h-full object-cover" />
              </div>
              
              <div className="p-6 overflow-y-auto">
                <h2 className="text-2xl font-serif font-bold text-[#3E2723] mb-2">{selectedItem.name}</h2>
                <p className="text-stone-500 text-sm mb-6">{selectedItem.description}</p>

                {selectedItem.customizations && (
                  <div className="mb-6">
                    <h3 className="font-medium text-[#3E2723] mb-3">Customizations</h3>
                    <div className="space-y-3">
                      {selectedItem.customizations.options.map((option, idx) => {
                        const isSelected = selectedCustomizations.some(c => c.name === option.name);
                        return (
                          <label key={idx} className="flex items-center justify-between p-3 border border-stone-200 rounded-xl cursor-pointer hover:bg-stone-50 transition-colors">
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-5 h-5 rounded flex items-center justify-center border transition-colors",
                                isSelected ? "bg-[#6B4423] border-[#6B4423]" : "border-stone-300"
                              )}>
                                {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                              </div>
                              <span className="text-stone-700">{option.name}</span>
                            </div>
                            <span className="text-stone-500 text-sm">+{option.price > 0 ? `₹${option.price}` : 'Free'}</span>
                            <input 
                              type="checkbox" 
                              className="hidden" 
                              checked={isSelected}
                              onChange={() => toggleCustomization(option)}
                            />
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-center gap-6 mb-8">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-12 h-12 rounded-full border border-stone-200 flex items-center justify-center text-stone-600 hover:bg-stone-50"
                  >
                    <Minus className="w-5 h-5" />
                  </button>
                  <span className="text-2xl font-medium w-8 text-center text-[#3E2723]">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-12 h-12 rounded-full border border-stone-200 flex items-center justify-center text-stone-600 hover:bg-stone-50"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>

                <button 
                  onClick={handleAddToCart}
                  className="w-full bg-[#6B4423] hover:bg-[#3E2723] text-white py-4 rounded-2xl font-medium text-lg transition-colors shadow-lg shadow-[#6B4423]/20"
                >
                  Add to Cart — ₹{(selectedItem.price + selectedCustomizations.reduce((s, c) => s + c.price, 0)) * quantity}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cart Modal */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 flex justify-end">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-white w-full max-w-md h-full relative z-10 flex flex-col shadow-2xl"
            >
              <div className="p-4 border-b border-stone-100 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-serif font-bold text-[#3E2723]">Your Order</h2>
                  <p className="text-stone-500 text-sm">Table {tableNumber}</p>
                </div>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="w-10 h-10 bg-stone-100 rounded-full flex items-center justify-center text-stone-500 hover:bg-stone-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-stone-400 gap-4">
                    <ShoppingCart className="w-16 h-16 opacity-20" />
                    <p>Your cart is empty</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {cart.map((item) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="w-20 h-20 rounded-xl overflow-hidden bg-stone-100 shrink-0">
                          <img src={item.menuItem.imageUrl} alt={item.menuItem.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-1">
                            <h4 className="font-medium text-[#3E2723]">{item.menuItem.name}</h4>
                            <span className="font-medium text-[#3E2723]">
                              ₹{(item.menuItem.price + item.selectedCustomizations.reduce((s, c) => s + c.price, 0)) * item.quantity}
                            </span>
                          </div>
                          <p className="text-sm text-stone-500 mb-2">Qty: {item.quantity} × ₹{item.menuItem.price}</p>
                          {item.selectedCustomizations.length > 0 && (
                            <ul className="text-xs text-stone-400 space-y-1 mb-2">
                              {item.selectedCustomizations.map((c, i) => (
                                <li key={i}>+ {c.name} (₹{c.price})</li>
                              ))}
                            </ul>
                          )}
                          <button 
                            onClick={() => setCart(cart.filter(c => c.id !== item.id))}
                            className="text-red-500 text-xs font-medium hover:underline"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-6 border-t border-stone-100 bg-stone-50">
                  <div className="mb-4">
                    <label htmlFor="orderNote" className="block text-sm font-medium text-stone-700 mb-1">Add a note (optional)</label>
                    <textarea
                      id="orderNote"
                      rows={2}
                      className="w-full rounded-xl bg-white border-stone-200 text-stone-900 placeholder-stone-400 shadow-sm focus:border-[#6B4423] focus:ring-[#6B4423] sm:text-sm p-3 border"
                      placeholder="e.g., Less spicy, extra napkins..."
                      value={orderNote}
                      onChange={(e) => setOrderNote(e.target.value)}
                    />
                  </div>
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-stone-700 font-medium">Total</span>
                    <span className="text-2xl font-bold text-[#3E2723]">₹{cartTotal}</span>
                  </div>
                  <button 
                    onClick={handleCheckout}
                    className="w-full bg-[#6B4423] hover:bg-[#3E2723] text-white py-4 rounded-2xl font-medium text-lg transition-colors shadow-lg shadow-[#6B4423]/20 flex items-center justify-center gap-2"
                  >
                    Place Order 🚀
                  </button>
                  <p className="text-center text-stone-500 text-xs mt-4">Pay at the counter after your meal</p>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Payment Page */}
      <AnimatePresence>
        {isPaymentOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed inset-0 z-50 bg-white flex flex-col"
          >
            <div className="p-4 border-b border-stone-100 bg-stone-50 flex items-center gap-4">
              <button onClick={() => { setIsPaymentOpen(false); setIsCartOpen(true); }} className="p-2 -ml-2 text-stone-500 hover:bg-stone-200 rounded-full">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h2 className="text-xl font-serif font-bold text-[#3E2723]">Payment Options</h2>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 max-w-lg mx-auto w-full">
              <div className="bg-stone-50 rounded-2xl p-6 shadow-sm border border-stone-100 mb-6 text-center">
                <p className="text-stone-500 text-sm mb-1">Amount to pay</p>
                <p className="text-4xl font-bold text-[#3E2723]">₹{cartTotal}</p>
              </div>

              <h3 className="font-medium text-[#3E2723] mb-4 px-2">Select Payment Method</h3>
              
              <div className="space-y-3">
                <button 
                  onClick={() => handlePaymentSelection('UPI')}
                  className="w-full bg-white p-4 rounded-2xl border border-stone-200 flex items-center gap-4 hover:border-[#6B4423] transition-colors text-left"
                >
                  <div className="w-12 h-12 bg-stone-100 rounded-xl flex items-center justify-center text-[#6B4423] shrink-0">
                    <Smartphone className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#3E2723]">UPI</h4>
                    <p className="text-sm text-stone-500">Paytm, GPay, PhonePe</p>
                  </div>
                </button>

                <button 
                  onClick={() => handlePaymentSelection('Net Banking')}
                  className="w-full bg-white p-4 rounded-2xl border border-stone-200 flex items-center gap-4 hover:border-[#6B4423] transition-colors text-left"
                >
                  <div className="w-12 h-12 bg-stone-100 rounded-xl flex items-center justify-center text-[#6B4423] shrink-0">
                    <Landmark className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#3E2723]">Net Banking</h4>
                    <p className="text-sm text-stone-500">All major banks supported</p>
                  </div>
                </button>

                <button 
                  onClick={() => handlePaymentSelection('Pay at Counter')}
                  className="w-full bg-white p-4 rounded-2xl border border-stone-200 flex items-center gap-4 hover:border-[#6B4423] transition-colors text-left"
                >
                  <div className="w-12 h-12 bg-stone-100 rounded-xl flex items-center justify-center text-[#6B4423] shrink-0">
                    <HandCoins className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#3E2723]">Pay at Counter</h4>
                    <p className="text-sm text-stone-500">Pay with cash or card after meal</p>
                  </div>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Processing Payment Overlay */}
      <AnimatePresence>
        {isProcessingPayment && (
          <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl p-8 flex flex-col items-center max-w-sm w-full shadow-2xl"
            >
              <div className="w-16 h-16 border-4 border-stone-200 border-t-[#6B4423] rounded-full animate-spin mb-6" />
              <h3 className="text-xl font-serif font-bold text-[#3E2723] mb-2">Processing Payment</h3>
              <p className="text-stone-500 text-center">Please do not close this window or press back.</p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Order Placed Page */}
      <AnimatePresence>
        {isOrderPlacedOpen && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 bg-white flex flex-col"
          >
            <div className="p-6">
              <h2 className="text-2xl font-serif font-bold text-[#3E2723]">Order Placed</h2>
            </div>
            
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-md mx-auto w-full">
              <div className="w-24 h-24 bg-stone-100 text-[#6B4423] rounded-full flex items-center justify-center mb-8">
                <CheckCircle2 className="w-12 h-12" />
              </div>
              <h3 className="text-3xl font-serif font-bold text-[#3E2723] mb-4">Thank You!</h3>
              <p className="text-stone-600 text-lg mb-12">
                Please be patient until your order arrives.
              </p>
              
              <button 
                onClick={() => {
                  setIsOrderPlacedOpen(false);
                  setIsOrdersModalOpen(true);
                }}
                className="w-full bg-[#6B4423] hover:bg-[#3E2723] text-white py-4 rounded-2xl font-medium text-lg transition-colors shadow-lg shadow-[#6B4423]/20"
              >
                Check your order
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Orders Modal */}
      <AnimatePresence>
        {isOrdersModalOpen && (
          <div className="fixed inset-0 z-50 flex justify-end">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOrdersModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-white w-full max-w-md h-full relative z-10 flex flex-col shadow-2xl"
            >
              <div className="p-4 border-b border-stone-100 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-serif font-bold text-[#3E2723]">Your Order</h2>
                  <p className="text-stone-500 text-sm">Table {tableNumber}</p>
                </div>
                <button 
                  onClick={() => setIsOrdersModalOpen(false)}
                  className="w-10 h-10 bg-stone-100 rounded-full flex items-center justify-center text-stone-500 hover:bg-stone-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 bg-stone-50">
                {pastOrders.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-stone-400 gap-4">
                    <History className="w-16 h-16 opacity-20" />
                    <p>No orders yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pastOrders.map((order) => (
                      <div 
                        key={order.id} 
                        className={cn(
                          "bg-white p-4 rounded-2xl shadow-sm border",
                          order.status === 'rejected' ? "border-red-200" : "border-stone-200"
                        )}
                      >
                        <div className="flex justify-between items-start mb-3 border-b border-stone-100 pb-3">
                          <div>
                            <span className={cn(
                              "text-xs font-bold px-2 py-1 rounded-full uppercase tracking-wider mb-2 inline-block",
                              order.status === 'new' && "bg-amber-100 text-amber-800",
                              order.status === 'preparing' && "bg-blue-100 text-blue-800",
                              order.status === 'ready' && "bg-green-100 text-green-800",
                              order.status === 'served' && "bg-green-100 text-green-800",
                              order.status === 'paid' && "bg-purple-100 text-purple-800",
                              order.status === 'rejected' && "bg-red-100 text-red-800"
                            )}>
                              {order.status === 'ready' ? 'Arriving' : order.status}
                            </span>
                            <div className="flex items-center text-stone-500 text-xs gap-2">
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                              {order.paymentMethod && (
                                <span className="flex items-center gap-1 border-l border-stone-200 pl-2">
                                  Payment: {order.paymentMethod}
                                </span>
                              )}
                            </div>
                          </div>
                          <span className="font-bold text-[#3E2723]">₹{order.total}</span>
                        </div>
                        <div className="space-y-2">
                          {order.items.map((item, idx) => (
                            <div key={idx} className="flex justify-between text-sm">
                              <span className="text-stone-700">{item.quantity}x {item.menuItem.name}</span>
                              <span className="text-stone-500">₹{item.menuItem.price * item.quantity}</span>
                            </div>
                          ))}
                        </div>
                        {order.status === 'rejected' && order.rejectionReason && (
                          <div className="mt-3 bg-red-50 text-red-800 p-3 rounded-xl text-sm border border-red-100">
                            <span className="font-bold">Reason:</span> {order.rejectionReason}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Rejected Order Alert */}
      <AnimatePresence>
        {rejectedOrderAlert && (
          <div 
            className="fixed inset-0 z-[70] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setRejectedOrderAlert(null)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl text-center relative overflow-hidden border border-red-100"
            >
              <div className="absolute top-0 left-0 right-0 h-2 bg-red-500" />
              <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <X className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-serif font-bold text-[#3E2723] mb-2">Order Cancelled</h3>
              <p className="text-stone-600 mb-4">
                We're sorry, but your order could not be processed.
              </p>
              {rejectedOrderAlert.rejectionReason && (
                <div className="bg-red-50 text-red-800 p-3 rounded-xl text-sm mb-6 border border-red-100 text-left">
                  <span className="font-bold block mb-1 text-red-600">Reason:</span>
                  {rejectedOrderAlert.rejectionReason}
                </div>
              )}
              <button 
                onClick={() => setRejectedOrderAlert(null)}
                className="w-full bg-[#6B4423] hover:bg-[#3E2723] text-white py-3 rounded-xl font-medium transition-colors"
              >
                Okay
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}