import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChefHat, CheckCircle2, Clock, Utensils, LogOut, BellRing, IndianRupee, XCircle, X } from 'lucide-react';
import { collection, query, onSnapshot, doc, updateDoc, orderBy, deleteDoc, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Order } from '../types';
import { cn } from '../lib/utils';

interface KitchenDashboardProps {
  onLogout: () => void;
}

export function KitchenDashboard({ onLogout }: KitchenDashboardProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [newOrderAlert, setNewOrderAlert] = useState<string | null>(null);
  const [rejectingOrderId, setRejectingOrderId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [mobileTab, setMobileTab] = useState<'Pending' | 'Preparing' | 'Ready' | 'Served'>('Pending');
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const prevOrdersCount = useRef<number>(0);

  useEffect(() => {
    // Initialize audio
    audioRef.current = new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg');

    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ordersData: Order[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        ordersData.push({
          ...data,
          id: doc.id,
          createdAt: data.createdAt?.toMillis() || Date.now(),
        } as Order);
      });

      // Check for new orders to play sound
      if (ordersData.length > prevOrdersCount.current) {
        const newOrders = ordersData.filter(o => o.status === 'Pending');
        if (newOrders.length > 0) {
          // Play sound
          if (audioRef.current) {
            audioRef.current.play().catch(e => console.log('Audio play failed:', e));
          }
          // Show visual alert
          setNewOrderAlert(`New order from Table ${newOrders[0].tableNumber}!`);
          setTimeout(() => setNewOrderAlert(null), 5000);
        }
      }
      prevOrdersCount.current = ordersData.length;
      setOrders(ordersData);
    });

    return () => unsubscribe();
  }, []);

  const updateOrderStatus = async (orderId: string, newStatus: Order['status'], reason?: string) => {
    try {
      const orderRef = doc(db, 'orders', orderId);
      const updateData: any = { status: newStatus };
      if (reason) updateData.rejectionReason = reason;
      await updateDoc(orderRef, updateData);
    } catch (error) {
      console.error("Error updating order status: ", error);
      alert("Failed to update order status.");
    }
  };

  const handleReject = () => {
    if (rejectingOrderId && rejectReason.trim()) {
      updateOrderStatus(rejectingOrderId, 'Cancelled', rejectReason.trim());
      setRejectingOrderId(null);
      setRejectReason('');
    }
  };

  const clearCompletedOrders = async () => {
    try {
      const q = query(collection(db, 'orders'), where('status', '==', 'Served'));
      const snapshot = await getDocs(q);
      const deletePromises = snapshot.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deletePromises);
    } catch (error) {
      console.error("Error clearing orders: ", error);
    }
  };

  const newOrders = orders.filter(o => o.status === 'Pending').sort((a, b) => b.createdAt - a.createdAt);
  const preparingOrders = orders.filter(o => o.status === 'Preparing').sort((a, b) => a.createdAt - b.createdAt);
  const readyOrders = orders.filter(o => o.status === 'Ready').sort((a, b) => b.createdAt - a.createdAt);
  const paidOrders = orders.filter(o => o.status === 'Served').sort((a, b) => b.createdAt - a.createdAt);

  const OrderCard: React.FC<{ order: Order }> = ({ order }) => (
    <motion.div 
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-white/5 p-5 rounded-2xl shadow-sm border border-white/10 flex flex-col gap-4"
    >
      <div className="flex justify-between items-start border-b border-white/10 pb-3">
        <div>
          <h3 className="text-xl font-bold text-white">Table {order.tableNumber}</h3>
          <p className="text-white/50 text-sm flex items-center gap-1 mt-1">
            <Clock className="w-3.5 h-3.5" />
            {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
          {order.paymentMethod && (
            <p className="text-white/70 text-xs font-medium mt-1 bg-white/10 inline-block px-2 py-0.5 rounded">
              Payment: {order.paymentMethod}
            </p>
          )}
        </div>
        <span className="font-bold text-amber-200 bg-amber-500/20 px-3 py-1 rounded-lg">₹{order.total}</span>
      </div>

      <div className="flex-1 space-y-3">
        {order.note && (
          <div className="bg-amber-500/10 border border-amber-500/20 text-amber-200 p-2 rounded-lg text-sm mb-3">
            <span className="font-bold">Note:</span> {order.note}
          </div>
        )}
        {order.items.map((item, idx) => (
          <div key={idx} className="flex gap-3">
            <div className="w-6 h-6 rounded bg-white/10 flex items-center justify-center text-white font-bold text-sm shrink-0">
              {item.quantity}
            </div>
            <div>
              <p className="font-medium text-white">{item.menuItem.name}</p>
              {item.selectedCustomizations.length > 0 && (
                <p className="text-sm text-white/50 mt-0.5">
                  + {item.selectedCustomizations.map(c => c.name).join(', ')}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="pt-3 border-t border-white/10 flex gap-2">
        {order.status === 'Pending' && (
          <>
            <button 
              onClick={() => updateOrderStatus(order.id, 'Preparing')}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" /> Accept
            </button>
            <button 
              onClick={() => setRejectingOrderId(order.id)}
              className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-200 py-2.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
            >
              <XCircle className="w-4 h-4" /> Reject
            </button>
          </>
        )}
        {order.status === 'Preparing' && (
          <button 
            onClick={() => updateOrderStatus(order.id, 'Ready')}
            className="flex-1 bg-amber-600 hover:bg-amber-700 text-white py-2.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
          >
            <ChefHat className="w-4 h-4" /> Mark Ready
          </button>
        )}
        {order.status === 'Ready' && (
          <>
            {order.paymentMethod === 'Pay at Counter' ? (
              <button 
                onClick={() => updateOrderStatus(order.id, 'Served')}
                className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
              >
                <IndianRupee className="w-4 h-4" /> Mark Paid
              </button>
            ) : (
              <button 
                onClick={() => updateOrderStatus(order.id, 'Served')}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" /> Paid Online ({order.paymentMethod})
              </button>
            )}
          </>
        )}
        {order.status === 'Served' && (
          <div className="flex-1 bg-white/10 text-white/50 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4" /> Completed
          </div>
        )}
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-[#F5E6D3] flex flex-col">
      {/* Header */}
      <header className="bg-[#3E2723] text-white p-4 shadow-md z-10">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
              <ChefHat className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-[family-name:var(--font-brand)] text-white">Demo Cafe</h1>
              <p className="text-white/70 text-sm">Real-time Order Management</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={clearCompletedOrders}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm font-medium transition-colors"
            >
              Clear Paid
            </button>
            <button onClick={onLogout} className="p-2 text-white/70 hover:text-white transition-colors">
              <LogOut className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Board */}
      <main className="flex-1 p-4 md:p-6 flex flex-col overflow-hidden">
        {/* Mobile Tabs */}
        <div className="md:hidden flex overflow-x-auto bg-[#3E2723] rounded-xl shadow-sm border border-white/10 mb-4 shrink-0">
          <button 
            onClick={() => setMobileTab('Pending')}
            className={cn("flex-1 py-3 px-3 text-sm font-bold whitespace-nowrap transition-colors flex items-center justify-center gap-2", mobileTab === 'Pending' ? "bg-amber-500/20 text-amber-200" : "text-white/50")}
          >
            New <span className={cn("px-2 py-0.5 rounded-full text-xs", mobileTab === 'Pending' ? "bg-amber-500/40" : "bg-white/10")}>{newOrders.length}</span>
          </button>
          <button 
            onClick={() => setMobileTab('Preparing')}
            className={cn("flex-1 py-3 px-3 text-sm font-bold whitespace-nowrap transition-colors flex items-center justify-center gap-2", mobileTab === 'Preparing' ? "bg-blue-500/20 text-blue-200" : "text-white/50")}
          >
            Prep <span className={cn("px-2 py-0.5 rounded-full text-xs", mobileTab === 'Preparing' ? "bg-blue-500/40" : "bg-white/10")}>{preparingOrders.length}</span>
          </button>
          <button 
            onClick={() => setMobileTab('Ready')}
            className={cn("flex-1 py-3 px-3 text-sm font-bold whitespace-nowrap transition-colors flex items-center justify-center gap-2", mobileTab === 'Ready' ? "bg-green-500/20 text-green-200" : "text-white/50")}
          >
            Ready <span className={cn("px-2 py-0.5 rounded-full text-xs", mobileTab === 'Ready' ? "bg-green-500/40" : "bg-white/10")}>{readyOrders.length}</span>
          </button>
          <button 
            onClick={() => setMobileTab('Served')}
            className={cn("flex-1 py-3 px-3 text-sm font-bold whitespace-nowrap transition-colors flex items-center justify-center gap-2", mobileTab === 'Served' ? "bg-purple-500/20 text-purple-200" : "text-white/50")}
          >
            Paid <span className={cn("px-2 py-0.5 rounded-full text-xs", mobileTab === 'Served' ? "bg-purple-500/40" : "bg-white/10")}>{paidOrders.length}</span>
          </button>
        </div>

        <div className="flex-1 overflow-x-auto overflow-y-hidden pb-2">
          <div className="flex flex-col md:grid md:grid-cols-4 gap-6 md:min-w-[1200px] h-full">
            
            {/* New Orders Column */}
            <div className={cn("flex-col bg-[#3E2723] rounded-2xl p-4 border border-white/10 h-full md:flex", mobileTab === 'Pending' ? "flex" : "hidden")}>
            <div className="flex items-center justify-between mb-4 px-2">
              <h2 className="font-bold text-white flex items-center gap-2">
                <BellRing className="w-5 h-5 text-amber-400" /> New Orders
              </h2>
              <span className="bg-amber-500/20 text-amber-200 text-xs font-bold px-2.5 py-1 rounded-full">
                {newOrders.length}
              </span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
              <AnimatePresence>
                {newOrders.map(order => <OrderCard key={order.id} order={order} />)}
              </AnimatePresence>
              {newOrders.length === 0 && (
                <div className="h-32 flex items-center justify-center text-white/50 text-sm border-2 border-dashed border-white/20 rounded-xl">
                  No new orders
                </div>
              )}
            </div>
          </div>

          {/* Preparing Column */}
          <div className={cn("flex-col bg-[#3E2723] rounded-2xl p-4 border border-white/10 h-full md:flex", mobileTab === 'Preparing' ? "flex" : "hidden")}>
            <div className="flex items-center justify-between mb-4 px-2">
              <h2 className="font-bold text-white flex items-center gap-2">
                <ChefHat className="w-5 h-5 text-blue-400" /> Preparing
              </h2>
              <span className="bg-blue-500/20 text-blue-200 text-xs font-bold px-2.5 py-1 rounded-full">
                {preparingOrders.length}
              </span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
              <AnimatePresence>
                {preparingOrders.map(order => <OrderCard key={order.id} order={order} />)}
              </AnimatePresence>
            </div>
          </div>

          {/* Ready Column */}
          <div className={cn("flex-col bg-[#3E2723] rounded-2xl p-4 border border-white/10 h-full md:flex", mobileTab === 'Ready' ? "flex" : "hidden")}>
            <div className="flex items-center justify-between mb-4 px-2">
              <h2 className="font-bold text-white flex items-center gap-2">
                <Utensils className="w-5 h-5 text-green-400" /> Ready
              </h2>
              <span className="bg-green-500/20 text-green-200 text-xs font-bold px-2.5 py-1 rounded-full">
                {readyOrders.length}
              </span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
              <AnimatePresence>
                {readyOrders.map(order => <OrderCard key={order.id} order={order} />)}
              </AnimatePresence>
            </div>
          </div>

          {/* Paid Column */}
          <div className={cn("flex-col bg-[#3E2723] rounded-2xl p-4 border border-white/10 h-full md:flex", mobileTab === 'Served' ? "flex" : "hidden")}>
            <div className="flex items-center justify-between mb-4 px-2">
              <h2 className="font-bold text-white flex items-center gap-2">
                <IndianRupee className="w-5 h-5 text-purple-400" /> Paid
              </h2>
              <span className="bg-purple-500/20 text-purple-200 text-xs font-bold px-2.5 py-1 rounded-full">
                {paidOrders.length}
              </span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
              <AnimatePresence>
                {paidOrders.map(order => <OrderCard key={order.id} order={order} />)}
              </AnimatePresence>
            </div>
          </div>

        </div>
        </div>
      </main>

      {/* Real-time Alert Toast */}
      <AnimatePresence>
        {newOrderAlert && (
          <motion.div 
            initial={{ opacity: 0, y: -50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: -50, x: '-50%' }}
            className="fixed top-6 left-1/2 z-50 bg-amber-500 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 font-bold text-lg"
          >
            <BellRing className="w-6 h-6 animate-bounce" />
            {newOrderAlert}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reject Reason Modal */}
      <AnimatePresence>
        {rejectingOrderId && (
          <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#3E2723] rounded-3xl p-6 w-full max-w-md shadow-2xl border border-white/10"
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-serif font-bold text-white">Reject Order</h3>
                <button 
                  onClick={() => {
                    setRejectingOrderId(null);
                    setRejectReason('');
                  }}
                  className="p-2 text-white/50 hover:bg-white/10 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-white/90 mb-2">
                  Reason for rejection
                </label>
                <textarea
                  className="w-full bg-white/5 border border-white/20 text-white placeholder-white/30 rounded-xl p-3 focus:ring-white focus:border-white"
                  rows={3}
                  placeholder="e.g., Item out of stock, kitchen busy..."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  autoFocus
                />
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => {
                    setRejectingOrderId(null);
                    setRejectReason('');
                  }}
                  className="flex-1 py-3 rounded-xl font-medium text-white/70 bg-white/10 hover:bg-white/20 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleReject}
                  disabled={!rejectReason.trim()}
                  className="flex-1 py-3 rounded-xl font-medium text-white bg-red-600 hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Confirm Reject
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
