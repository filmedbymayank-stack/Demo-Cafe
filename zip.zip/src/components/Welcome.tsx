import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Coffee } from 'lucide-react';

interface WelcomeProps {
  onEnter: (tableNumber: string) => void;
}

export function Welcome({ onEnter }: WelcomeProps) {
  const [table, setTable] = useState('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (table.trim()) {
      onEnter(table.trim());
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#6B4423] to-[#3E2723] flex flex-col items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center mb-10 w-full max-w-md"
      >
        <div className="w-20 h-20 bg-white/10 backdrop-blur-md rounded-3xl flex items-center justify-center mb-4 border border-white/20">
          <Coffee className="text-white w-10 h-10" />
        </div>
        <h1 className="text-5xl sm:text-6xl font-[family-name:var(--font-brand)] text-[#F5E6D3] mb-3 tracking-wide drop-shadow-sm text-center">
          Demo Cafe
        </h1>
        <p className="text-white/80 text-lg font-serif italic">Specialty Coffee & Kitchen</p>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-white w-full max-w-sm rounded-[2rem] p-8 shadow-2xl text-center"
      >
        <h2 className="text-2xl font-serif font-bold text-stone-900 mb-2">Welcome! 👋</h2>
        <p className="text-stone-500 mb-8">Enter your table number to browse the menu</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="number"
            value={table}
            onChange={(e) => setTable(e.target.value)}
            placeholder="e.g. 7"
            className="w-full text-center text-2xl py-4 rounded-2xl border-2 border-stone-200 focus:border-[#6B4423] focus:ring-0 outline-none transition-colors"
            required
            min="1"
            max="100"
          />
          <button
            type="submit"
            className="w-full bg-[#A68A7B] hover:bg-[#8A7163] text-white text-lg font-medium py-4 rounded-2xl transition-colors flex items-center justify-center gap-2"
          >
            View Menu &rarr;
          </button>
        </form>

        <p className="text-stone-400 text-sm mt-8">Pay at the counter after your meal</p>
      </motion.div>
    </div>
  );
}
