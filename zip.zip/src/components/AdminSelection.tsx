import { motion } from 'motion/react';
import { ChefHat, UtensilsCrossed, LogOut } from 'lucide-react';

interface AdminSelectionProps {
  onSelect: (view: 'kitchen-dashboard' | 'welcome') => void;
  onLogout: () => void;
}

export function AdminSelection({ onSelect, onLogout }: AdminSelectionProps) {
  return (
    <div className="min-h-screen bg-[#F5E6D3] p-6 flex flex-col">
      <div className="flex justify-between items-center mb-12">
        <h1 className="text-3xl font-[family-name:var(--font-brand)] text-[#6B4423]">Demo Cafe</h1>
        <button onClick={onLogout} className="p-2 text-[#6B4423]/70 hover:bg-[#6B4423]/10 rounded-full transition-colors">
          <LogOut className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl font-serif font-bold text-[#3E2723] mb-2">Admin Portal</h2>
          <p className="text-[#6B4423]/70">Select your operating mode</p>
        </motion.div>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          onClick={() => onSelect('kitchen-dashboard')}
          className="w-full bg-[#6B4423] text-white p-6 rounded-3xl flex flex-col items-center gap-4 hover:bg-[#5A391D] transition-colors shadow-lg"
        >
          <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center">
            <ChefHat className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-medium">Kitchen Dashboard</h3>
            <p className="text-white/70 text-sm mt-1">Manage incoming orders and status</p>
          </div>
        </motion.button>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          onClick={() => onSelect('welcome')}
          className="w-full bg-white text-[#3E2723] p-6 rounded-3xl flex flex-col items-center gap-4 hover:bg-white/90 transition-colors shadow-sm border border-[#6B4423]/10"
        >
          <div className="w-16 h-16 bg-[#F5E6D3] rounded-full flex items-center justify-center">
            <UtensilsCrossed className="w-8 h-8 text-[#6B4423]" />
          </div>
          <div>
            <h3 className="text-xl font-medium">Customer Menu</h3>
            <p className="text-[#6B4423]/70 text-sm mt-1">View the ordering interface</p>
          </div>
        </motion.button>
      </div>
    </div>
  );
}
