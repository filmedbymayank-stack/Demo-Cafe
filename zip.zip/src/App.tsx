import { useState, useEffect } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import { Login } from './components/Login';
import { AdminSelection } from './components/AdminSelection';
import { Welcome } from './components/Welcome';
import { CustomerMenu } from './components/CustomerMenu';
import { KitchenDashboard } from './components/KitchenDashboard';
import { SplashScreen } from './components/SplashScreen';
import { User } from './types';

type View = 'login' | 'admin-selection' | 'welcome' | 'customer-menu' | 'kitchen-dashboard';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<View>('login');
  const [tableNumber, setTableNumber] = useState<string | null>(null);
  const [showSplash, setShowSplash] = useState(true);
  const [loading, setLoading] = useState(true);

  // Check URL params for table number on load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const table = params.get('table');
    if (table) {
      setTableNumber(table);
    }
  }, []);

  // Listen for auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          // Fetch user role from Firestore
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          let userDoc = await getDoc(userDocRef);
          
          if (!userDoc.exists()) {
            // If user doc doesn't exist, create it (e.g. first time Google login)
            const role = firebaseUser.email?.toLowerCase().trim() === 'filmedbymayank@gmail.com' ? 'admin' : 'customer';
            const userData = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              role: role
            };
            await setDoc(userDocRef, userData);
            userDoc = await getDoc(userDocRef);
          }

          if (userDoc.exists()) {
            const userData = userDoc.data() as User;
            setUser(userData);
            
            if (userData.role === 'admin') {
              setView('admin-selection');
            } else {
              if (tableNumber) {
                setView('customer-menu');
              } else {
                setView('welcome');
              }
            }
          }
        } catch (error) {
          console.error("Error fetching/creating user doc:", error);
          await signOut(auth);
          setUser(null);
          setView('login');
        }
      } else {
        setUser(null);
        setView('login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [tableNumber]);

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    setView('login');
    setTableNumber(null);
  };

  const handleTableEnter = (table: string) => {
    setTableNumber(table);
    setView('customer-menu');
  };

  const handleAdminSelect = (selectedView: 'kitchen-dashboard' | 'welcome') => {
    setView(selectedView);
  };

  if (loading) {
    return <SplashScreen onComplete={() => {}} />;
  }

  const renderView = () => {
    switch (view) {
      case 'login':
        return <Login onLogin={() => {}} />; // Login component handles its own logic now
        
      case 'admin-selection':
        if (user?.role !== 'admin') {
          setView('welcome');
          return null;
        }
        return <AdminSelection onSelect={handleAdminSelect} onLogout={handleLogout} />;
        
      case 'welcome':
        return <Welcome onEnter={handleTableEnter} />;
        
      case 'customer-menu':
        if (!tableNumber) {
          setView('welcome');
          return null;
        }
        return <CustomerMenu tableNumber={tableNumber} onLogout={handleLogout} />;
        
      case 'kitchen-dashboard':
        if (user?.role !== 'admin') {
          setView('welcome');
          return null;
        }
        return <KitchenDashboard onLogout={handleLogout} />;
        
      default:
        return <Login onLogin={() => {}} />;
    }
  };

  return (
    <>
      {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}
      {renderView()}
    </>
  );
}
